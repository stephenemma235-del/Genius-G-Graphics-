import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const bg = readFileSync(
  "/workspace/artifacts/imagine_images/d02316f0-67f1-45e5-9159-e3e44a248b42.jpg",
).toString("base64");
const logo = readFileSync("/workspace/public/logo.png").toString("base64");
const fontBold = readFileSync("/workspace/.grok/font-bold.b64", "utf8");
const fontItalic = readFileSync("/workspace/.grok/font-italic.b64", "utf8");

const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<style>
@font-face {
  font-family: "Studio Serif";
  src: url(data:font/ttf;base64,${fontBold}) format("truetype");
  font-weight: 700;
  font-style: normal;
}
@font-face {
  font-family: "Studio Serif";
  src: url(data:font/ttf;base64,${fontItalic}) format("truetype");
  font-weight: 400;
  font-style: italic;
}
html, body {
  margin: 0;
  width: 1792px;
  height: 1008px;
  overflow: hidden;
  background: #F3EFE6;
}
.card {
  width: 1792px;
  height: 1008px;
  box-sizing: border-box;
  background:
    url("data:image/jpeg;base64,${bg}") center / cover no-repeat;
  display: flex;
  align-items: center;
  justify-content: center;
}
.lockup {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  width: 1100px;
}
.title {
  margin: 0;
  padding-left: 0.26em;
  font-family: "Studio Serif", serif;
  font-weight: 700;
  font-style: normal;
  font-size: 38px;
  letter-spacing: 0.26em;
  color: #141210;
  line-height: 1;
  text-transform: uppercase;
}
.logo {
  width: 620px;
  height: auto;
  margin: 40px 0 0;
  display: block;
}
.rule-row {
  display: flex;
  align-items: center;
  gap: 22px;
  margin-top: 36px;
}
.rule {
  width: 64px;
  height: 1px;
  background: #6E6860;
  opacity: 0.5;
}
.sub {
  margin: 0;
  font-family: "Studio Serif", serif;
  font-weight: 400;
  font-style: italic;
  font-size: 24px;
  letter-spacing: 0.08em;
  color: #6E6860;
  line-height: 1;
}
</style>
</head>
<body>
  <div class="card">
    <div class="lockup">
      <p class="title">GENIUS G GRAPHIC DESIGNS</p>
      <img class="logo" alt="" src="data:image/png;base64,${logo}" />
      <div class="rule-row">
        <span class="rule"></span>
        <p class="sub">Where genius meets design · Ado Ekiti</p>
        <span class="rule"></span>
      </div>
    </div>
  </div>
</body>
</html>`;

const browser = await chromium.launch({
  args: ["--font-render-hinting=none"],
});
const page = await browser.newPage({
  viewport: { width: 1792, height: 1008 },
  deviceScaleFactor: 1,
});
await page.setContent(html, { waitUntil: "load" });
await page.evaluate(async () => document.fonts.ready);
await page.screenshot({
  path: "/workspace/.grok/og-preview.png",
  type: "png",
});
await browser.close();
console.log("wrote /workspace/.grok/og-preview.png");
