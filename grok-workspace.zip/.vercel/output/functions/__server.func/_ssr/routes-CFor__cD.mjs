import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as MessageCircle, c as ArrowUpRight, i as Monitor, l as ArrowDown, o as Menu, r as Printer, s as MapPin, t as X } from "../_libs/lucide-react.mjs";
import { a as defaultWhatsappText, i as WORK, n as BRAND, o as whatsappHref, r as SERVICES } from "./router-CS2_olUZ.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CFor__cD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium whitespace-nowrap transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-primary text-primary-foreground shadow-[var(--shadow-border)] hover:opacity-90",
			outline: "bg-transparent text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] hover:bg-card",
			ghost: "bg-transparent text-foreground hover:bg-muted"
		},
		size: {
			md: "h-11 rounded-md px-5 text-sm",
			lg: "h-12 rounded-lg px-6 text-sm tracking-wide",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md bg-card px-3.5 text-base text-foreground shadow-[var(--shadow-border)] outline-none transition-[box-shadow] duration-150 placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-ring md:text-sm", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-mark font-medium tracking-mark text-muted-foreground uppercase", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-32 w-full rounded-lg bg-card px-3.5 py-3 text-base text-foreground shadow-[var(--shadow-border)] outline-none transition-[box-shadow] duration-150 placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-ring md:text-sm", className),
		...props
	});
}
var SERVICE_OPTIONS = [...SERVICES.map((s) => ({
	id: s.id,
	title: s.title
})), {
	id: "other",
	title: "Something else"
}];
function RequestForm() {
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [place, setPlace] = (0, import_react.useState)("");
	const [service, setService] = (0, import_react.useState)("flyers");
	const [delivery, setDelivery] = (0, import_react.useState)("virtual");
	const [details, setDetails] = (0, import_react.useState)("");
	const [opened, setOpened] = (0, import_react.useState)(false);
	const serviceTitle = SERVICE_OPTIONS.find((s) => s.id === service)?.title ?? service;
	const message = (0, import_react.useMemo)(() => {
		return [
			`Hello ${BRAND.name},`,
			"",
			"I would like to request a design.",
			"",
			`Name: ${name.trim() || "—"}`,
			phone.trim() ? `Phone: ${phone.trim()}` : null,
			`Location: ${place.trim() || "—"}`,
			`Service: ${serviceTitle}`,
			delivery === "physical" ? `Delivery: Physical print in ${BRAND.city}` : "Delivery: Virtual files (nationwide)",
			"",
			"Brief:",
			details.trim() || "—"
		].filter((line) => line !== null).join("\n");
	}, [
		name,
		phone,
		place,
		serviceTitle,
		delivery,
		details
	]);
	const href = whatsappHref(message);
	function onSubmit(event) {
		event.preventDefault();
		setOpened(true);
		window.open(href, "_blank", "noopener,noreferrer");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "grid gap-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Your name",
					htmlFor: "name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "name",
						name: "name",
						autoComplete: "name",
						required: true,
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Full name"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Phone",
					htmlFor: "phone",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "phone",
						name: "phone",
						type: "tel",
						autoComplete: "tel",
						value: phone,
						onChange: (e) => setPhone(e.target.value),
						placeholder: "080…"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "text-mark font-medium tracking-mark text-muted-foreground uppercase",
					children: "Service"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: SERVICE_OPTIONS.map((option) => {
						const active = service === option.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: cn("flex min-h-11 cursor-pointer items-center justify-center rounded-md px-3 text-center text-sm transition-[background-color,color,box-shadow] duration-150", active ? "bg-primary text-primary-foreground" : "bg-card text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								name: "service",
								value: option.id,
								checked: active,
								onChange: () => setService(option.id),
								className: "sr-only"
							}), option.title]
						}, option.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "text-mark font-medium tracking-mark text-muted-foreground uppercase",
					children: "Delivery"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeliveryCard, {
						title: "Virtual files",
						copy: "Logos, flyers, brand kits — sent anywhere in Nigeria after payment.",
						active: delivery === "virtual",
						onSelect: () => setDelivery("virtual")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeliveryCard, {
						title: `Physical · ${BRAND.city}`,
						copy: "Printed flyers, banners, and frames. We only deliver in person within Ado Ekiti.",
						active: delivery === "physical",
						onSelect: () => setDelivery("physical")
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: delivery === "physical" ? `Area in ${BRAND.city}` : "City / state",
				htmlFor: "place",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "place",
					name: "place",
					required: true,
					value: place,
					onChange: (e) => setPlace(e.target.value),
					placeholder: delivery === "physical" ? "e.g. Ajilosun, Ado Ekiti" : "e.g. Ibadan, Oyo"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "The brief",
				htmlFor: "details",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "details",
					name: "details",
					required: true,
					value: details,
					onChange: (e) => setDetails(e.target.value),
					placeholder: "What do you need, when do you need it, and any sizes, colours, or examples."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "This opens WhatsApp with your brief. Price is agreed there before work starts. Nothing is stored on this site."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					size: "lg",
					className: "min-h-12 sm:min-w-52",
					children: ["Send on WhatsApp", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
				}), opened ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href,
					target: "_blank",
					rel: "noreferrer",
					className: "text-sm underline-offset-4 hover:underline",
					children: "If WhatsApp did not open, tap here."
				}) : null]
			})
		]
	});
}
function Field({ label, htmlFor, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			htmlFor,
			children: label
		}), children]
	});
}
function DeliveryCard({ title, copy, active, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onSelect,
		className: cn("rounded-lg p-4 text-left transition-[background-color,box-shadow] duration-150", active ? "bg-primary text-primary-foreground" : "bg-card text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-serif text-xl tracking-tight",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("mt-1.5 text-sm leading-relaxed", active ? "text-primary-foreground/75" : "text-muted-foreground"),
			children: copy
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-border bg-foreground text-primary-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:px-8 md:grid-cols-[1.4fr_1fr_1fr]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-serif text-3xl tracking-tight",
					children: BRAND.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 max-w-sm text-sm leading-relaxed text-primary-foreground/70",
					children: [
						BRAND.tagline,
						". Designed in ",
						BRAND.city,
						", delivered across",
						" ",
						BRAND.country,
						"."
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-mark tracking-mark uppercase text-primary-foreground/50",
					children: "Studio"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm leading-relaxed",
					children: [
						BRAND.city,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						BRAND.state,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						BRAND.country
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-mark tracking-mark uppercase text-primary-foreground/50",
					children: "WhatsApp"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: whatsappHref(defaultWhatsappText()),
					target: "_blank",
					rel: "noreferrer",
					className: "mt-3 inline-flex min-h-11 items-center text-sm underline-offset-4 hover:underline",
					children: BRAND.whatsappDisplay
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-primary-foreground/10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-xs text-primary-foreground/50 sm:flex-row sm:justify-between sm:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"Physical deliveries in ",
					BRAND.city,
					" only. Virtual files nationwide."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" ",
					BRAND.short
				] })]
			})
		})]
	});
}
var NAV = [
	{
		href: "#services",
		label: "Services"
	},
	{
		href: "#work",
		label: "Work"
	},
	{
		href: "#delivery",
		label: "Delivery"
	},
	{
		href: "#request",
		label: "Request"
	}
];
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-border/80 bg-background/90 backdrop-blur-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:h-[4.5rem] sm:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#top",
					className: "flex min-h-11 items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-serif text-xl leading-none tracking-tight text-foreground sm:text-2xl",
						children: BRAND.short
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-8 md:flex",
					"aria-label": "Primary",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						className: "text-sm text-muted-foreground transition-colors duration-150 hover:text-foreground",
						children: item.label
					}, item.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "md",
						className: "hidden sm:inline-flex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#request",
							children: "Request a design"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon",
						className: "md:hidden",
						"aria-expanded": open,
						"aria-controls": "mobile-nav",
						"aria-label": open ? "Close menu" : "Open menu",
						onClick: () => setOpen((v) => !v),
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			id: "mobile-nav",
			className: cn("md:hidden overflow-hidden border-t border-border bg-background transition-[max-height,opacity] duration-200 ease-[cubic-bezier(0.22,1,0.36,1)]", open ? "max-h-[100dvh] opacity-100" : "max-h-0 opacity-0"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex min-h-[calc(100dvh-4rem)] flex-col px-6 py-8",
				"aria-label": "Mobile",
				children: [NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: item.href,
					onClick: () => setOpen(false),
					className: "border-b border-border py-4 font-serif text-4xl tracking-tight text-foreground",
					children: item.label
				}, item.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#request",
							onClick: () => setOpen(false),
							children: "Request a design"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: whatsappHref(defaultWhatsappText()),
							target: "_blank",
							rel: "noreferrer",
							onClick: () => setOpen(false),
							children: ["WhatsApp ", BRAND.whatsappDisplay]
						})
					})]
				})]
			})
		})]
	});
}
function WhatsappFab() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: whatsappHref(defaultWhatsappText()),
		target: "_blank",
		rel: "noreferrer",
		className: "fixed right-4 bottom-[max(1rem,env(safe-area-inset-bottom))] z-30 inline-flex h-12 items-center gap-2 rounded-full bg-primary px-4 text-sm font-medium text-primary-foreground shadow-[var(--shadow-border-hover)] transition-transform duration-150 ease-out active:scale-[0.96] md:hidden",
		"aria-label": `Chat on WhatsApp ${BRAND.whatsappDisplay}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
			className: "size-4",
			strokeWidth: 1.75
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pr-0.5",
			children: "WhatsApp"
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "top",
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "pb-16 md:pb-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Work, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delivery, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Process, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Request, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappFab, {})
		]
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl px-5 pb-20 pt-12 sm:px-8 sm:pt-16 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:gap-12 lg:pb-28 lg:pt-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "reveal text-mark tracking-mark text-muted-foreground uppercase",
					children: [
						BRAND.city,
						" · ",
						BRAND.country
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "reveal reveal-delay-1 mt-5 font-serif text-display leading-[0.95] tracking-display text-foreground",
					children: [BRAND.tagline, "."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "reveal reveal-delay-2 mt-6 max-w-md text-lead text-muted-foreground",
					children: [
						"Flyers, logos, branding, banners, and picture frames. Physical prints in ",
						BRAND.city,
						". Virtual files anywhere in Nigeria — once payment is in."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "reveal reveal-delay-3 mt-8 flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#request",
							children: "Request a design"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: whatsappHref(defaultWhatsappText()),
							target: "_blank",
							rel: "noreferrer",
							children: "Chat on WhatsApp"
						})
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "reveal reveal-delay-2 mt-14 flex justify-center lg:mt-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full max-w-md rounded-xl bg-card px-8 py-10 shadow-[var(--shadow-border)] sm:px-12 sm:py-14",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/logo.png",
						alt: `${BRAND.name} logo`,
						className: "mx-auto h-auto w-full max-w-xs"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-center text-mark tracking-mark text-muted-foreground uppercase",
						children: BRAND.tagline
					})]
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "#services",
			className: "mx-auto mb-10 flex h-11 w-11 items-center justify-center text-muted-foreground transition-colors duration-150 hover:text-foreground",
			"aria-label": "See services",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-4" })
		})]
	});
}
function Services() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "services",
		className: "scroll-mt-20 border-t border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-mark tracking-mark text-muted-foreground uppercase",
					children: "The studio"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-section tracking-tight",
					children: "Everything a designer does."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-sm leading-relaxed text-muted-foreground sm:text-right",
					children: "One brief. One WhatsApp chat. From a single flyer to a full brand."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-12 grid gap-px overflow-hidden rounded-xl bg-border shadow-[var(--shadow-border)] sm:grid-cols-2 lg:grid-cols-3",
				children: SERVICES.map((service, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "bg-card p-6 sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-serif text-sm text-muted-foreground",
							children: String(index + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-5 font-serif text-3xl tracking-tight",
							children: service.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted-foreground",
							children: service.copy
						})
					]
				}, service.id))
			})]
		})
	});
}
function Work() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "work",
		className: "scroll-mt-20 border-t border-border bg-muted/40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-mark tracking-mark text-muted-foreground uppercase",
					children: "Selected work"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-section tracking-tight",
					children: "Ink on paper."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
					children: WORK.map((piece) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "group",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: piece.src,
								alt: piece.alt,
								className: "work-frame aspect-work w-full object-cover transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-105"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-baseline justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-serif text-xl tracking-tight",
								children: piece.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-mark tracking-mark text-muted-foreground uppercase",
								children: piece.kind
							})]
						})]
					}, piece.src))
				})
			]
		})
	});
}
function Delivery() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "delivery",
		className: "scroll-mt-20 border-t border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-mark tracking-mark text-muted-foreground uppercase",
					children: "How it arrives"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 max-w-xl font-serif text-section tracking-tight",
					children: "Printed in Ado Ekiti. Sent everywhere else."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-12 grid gap-4 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl bg-card p-7 shadow-[var(--shadow-border)] sm:p-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {
								className: "size-5",
								strokeWidth: 1.5
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-6 font-serif text-3xl tracking-tight",
								children: "Physical delivery"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 flex items-center gap-2 text-sm text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }),
									BRAND.city,
									" only"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-5 max-w-md text-sm leading-relaxed text-muted-foreground",
								children: [
									"Flyers, banners, and framed pieces we can print and put in your hand. If you are not in ",
									BRAND.city,
									", choose virtual files and print locally."
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl bg-foreground p-7 text-primary-foreground shadow-[var(--shadow-border)] sm:p-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, {
								className: "size-5",
								strokeWidth: 1.5
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-6 font-serif text-3xl tracking-tight",
								children: "Virtual delivery"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-primary-foreground/65",
								children: "All of Nigeria · after payment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-md text-sm leading-relaxed text-primary-foreground/75",
								children: "Logos, brand kits, and print-ready artwork delivered as files. Pay, receive, print or post from wherever you are."
							})
						]
					})]
				})
			]
		})
	});
}
function Process() {
	const steps = [
		{
			n: "01",
			title: "Send the brief",
			copy: "Use the form or WhatsApp. Tell us what you need, where you are, and when you need it."
		},
		{
			n: "02",
			title: "Agree the price",
			copy: "We confirm the job and the fee on WhatsApp before any design starts."
		},
		{
			n: "03",
			title: "Design",
			copy: "You get drafts, you mark changes, we finish the work."
		},
		{
			n: "04",
			title: "Deliver",
			copy: `Files anywhere in Nigeria. Prints and frames only in ${BRAND.city}.`
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-border bg-muted/40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-section tracking-tight",
				children: "Four steps."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-12 grid gap-10 sm:grid-cols-2 lg:grid-cols-4",
				children: steps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-sm text-muted-foreground",
						children: step.n
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-4 font-serif text-2xl tracking-tight",
						children: step.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted-foreground",
						children: step.copy
					})
				] }, step.n))
			})]
		})
	});
}
function Request() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "request",
		className: "scroll-mt-20 border-t border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 sm:py-24 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-mark tracking-mark text-muted-foreground uppercase",
					children: "The brief"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-section tracking-tight",
					children: "Request a design."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-5 max-w-sm text-lead text-muted-foreground",
					children: [
						"Fill this in and it opens WhatsApp with your message ready to send to ",
						BRAND.whatsappDisplay,
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: whatsappHref(defaultWhatsappText()),
					target: "_blank",
					rel: "noreferrer",
					className: "mt-8 inline-flex min-h-11 items-center text-sm underline-offset-4 hover:underline",
					children: "Or skip the form and chat now"
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl bg-muted/60 p-5 sm:p-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestForm, {})
			})]
		})
	});
}
//#endregion
export { Home as component };
