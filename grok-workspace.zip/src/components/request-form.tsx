import { useMemo, useState, type FormEvent, type ReactNode } from "react";
import { ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { BRAND, SERVICES, whatsappHref } from "@/lib/brand";
import { cn } from "@/lib/utils";

type Delivery = "virtual" | "physical";

const SERVICE_OPTIONS = [
  ...SERVICES.map((s) => ({ id: s.id, title: s.title })),
  { id: "other", title: "Something else" },
];

export function RequestForm() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [place, setPlace] = useState("");
  const [service, setService] = useState("flyers");
  const [delivery, setDelivery] = useState<Delivery>("virtual");
  const [details, setDetails] = useState("");
  const [opened, setOpened] = useState(false);

  const serviceTitle =
    SERVICE_OPTIONS.find((s) => s.id === service)?.title ?? service;

  const message = useMemo(() => {
    const lines = [
      `Hello ${BRAND.name},`,
      "",
      "I would like to request a design.",
      "",
      `Name: ${name.trim() || "—"}`,
      phone.trim() ? `Phone: ${phone.trim()}` : null,
      `Location: ${place.trim() || "—"}`,
      `Service: ${serviceTitle}`,
      delivery === "physical"
        ? `Delivery: Physical print in ${BRAND.city}`
        : "Delivery: Virtual files (nationwide)",
      "",
      "Brief:",
      details.trim() || "—",
    ];
    return lines.filter((line) => line !== null).join("\n");
  }, [name, phone, place, serviceTitle, delivery, details]);

  const href = whatsappHref(message);

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    setOpened(true);
    window.open(href, "_blank", "noopener,noreferrer");
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-7">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Your name" htmlFor="name">
          <Input
            id="name"
            name="name"
            autoComplete="name"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Full name"
          />
        </Field>
        <Field label="Phone" htmlFor="phone">
          <Input
            id="phone"
            name="phone"
            type="tel"
            autoComplete="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="080…"
          />
        </Field>
      </div>

      <fieldset className="grid gap-3">
        <legend className="text-mark font-medium tracking-mark text-muted-foreground uppercase">
          Service
        </legend>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {SERVICE_OPTIONS.map((option) => {
            const active = service === option.id;
            return (
              <label
                key={option.id}
                className={cn(
                  "flex min-h-11 cursor-pointer items-center justify-center rounded-md px-3 text-center text-sm transition-[background-color,color,box-shadow] duration-150",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "bg-card text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
                )}
              >
                <input
                  type="radio"
                  name="service"
                  value={option.id}
                  checked={active}
                  onChange={() => setService(option.id)}
                  className="sr-only"
                />
                {option.title}
              </label>
            );
          })}
        </div>
      </fieldset>

      <fieldset className="grid gap-3">
        <legend className="text-mark font-medium tracking-mark text-muted-foreground uppercase">
          Delivery
        </legend>
        <div className="grid gap-2 sm:grid-cols-2">
          <DeliveryCard
            title="Virtual files"
            copy="Logos, flyers, brand kits — sent anywhere in Nigeria after payment."
            active={delivery === "virtual"}
            onSelect={() => setDelivery("virtual")}
          />
          <DeliveryCard
            title={`Physical · ${BRAND.city}`}
            copy="Printed flyers, banners, and frames. We only deliver in person within Ado Ekiti."
            active={delivery === "physical"}
            onSelect={() => setDelivery("physical")}
          />
        </div>
      </fieldset>

      <Field
        label={
          delivery === "physical"
            ? `Area in ${BRAND.city}`
            : "City / state"
        }
        htmlFor="place"
      >
        <Input
          id="place"
          name="place"
          required
          value={place}
          onChange={(e) => setPlace(e.target.value)}
          placeholder={
            delivery === "physical" ? "e.g. Ajilosun, Ado Ekiti" : "e.g. Ibadan, Oyo"
          }
        />
      </Field>

      <Field label="The brief" htmlFor="details">
        <Textarea
          id="details"
          name="details"
          required
          value={details}
          onChange={(e) => setDetails(e.target.value)}
          placeholder="What do you need, when do you need it, and any sizes, colours, or examples."
        />
      </Field>

      <p className="text-sm text-muted-foreground">
        This opens WhatsApp with your brief. Price is agreed there before work
        starts. Nothing is stored on this site.
      </p>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <Button type="submit" size="lg" className="min-h-12 sm:min-w-52">
          Send on WhatsApp
          <ArrowUpRight className="size-4" />
        </Button>
        {opened ? (
          <a
            href={href}
            target="_blank"
            rel="noreferrer"
            className="text-sm underline-offset-4 hover:underline"
          >
            If WhatsApp did not open, tap here.
          </a>
        ) : null}
      </div>
    </form>
  );
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor: string;
  children: ReactNode;
}) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
    </div>
  );
}

function DeliveryCard({
  title,
  copy,
  active,
  onSelect,
}: {
  title: string;
  copy: string;
  active: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "rounded-lg p-4 text-left transition-[background-color,box-shadow] duration-150",
        active
          ? "bg-primary text-primary-foreground"
          : "bg-card text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
      )}
    >
      <p className="font-serif text-xl tracking-tight">{title}</p>
      <p
        className={cn(
          "mt-1.5 text-sm leading-relaxed",
          active ? "text-primary-foreground/75" : "text-muted-foreground",
        )}
      >
        {copy}
      </p>
    </button>
  );
}
