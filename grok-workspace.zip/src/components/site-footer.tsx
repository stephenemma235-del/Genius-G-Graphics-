import { BRAND, defaultWhatsappText, whatsappHref } from "@/lib/brand";

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-foreground text-primary-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:px-8 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <p className="font-serif text-3xl tracking-tight">{BRAND.name}</p>
          <p className="mt-3 max-w-sm text-sm leading-relaxed text-primary-foreground/70">
            {BRAND.tagline}. Designed in {BRAND.city}, delivered across{" "}
            {BRAND.country}.
          </p>
        </div>
        <div>
          <p className="text-mark tracking-mark uppercase text-primary-foreground/50">
            Studio
          </p>
          <p className="mt-3 text-sm leading-relaxed">
            {BRAND.city}
            <br />
            {BRAND.state}
            <br />
            {BRAND.country}
          </p>
        </div>
        <div>
          <p className="text-mark tracking-mark uppercase text-primary-foreground/50">
            WhatsApp
          </p>
          <a
            href={whatsappHref(defaultWhatsappText())}
            target="_blank"
            rel="noreferrer"
            className="mt-3 inline-flex min-h-11 items-center text-sm underline-offset-4 hover:underline"
          >
            {BRAND.whatsappDisplay}
          </a>
        </div>
      </div>
      <div className="border-t border-primary-foreground/10">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-xs text-primary-foreground/50 sm:flex-row sm:justify-between sm:px-8">
          <p>
            Physical deliveries in {BRAND.city} only. Virtual files nationwide.
          </p>
          <p>© {new Date().getFullYear()} {BRAND.short}</p>
        </div>
      </div>
    </footer>
  );
}
