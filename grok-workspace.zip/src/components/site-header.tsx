import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BRAND, defaultWhatsappText, whatsappHref } from "@/lib/brand";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "#services", label: "Services" },
  { href: "#work", label: "Work" },
  { href: "#delivery", label: "Delivery" },
  { href: "#request", label: "Request" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="sticky top-0 z-40 border-b border-border/80 bg-background/90 backdrop-blur-sm">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:h-[4.5rem] sm:px-8">
        <a href="#top" className="flex min-h-11 items-center">
          <span className="font-serif text-xl leading-none tracking-tight text-foreground sm:text-2xl">
            {BRAND.short}
          </span>
        </a>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Primary">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm text-muted-foreground transition-colors duration-150 hover:text-foreground"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button asChild size="md" className="hidden sm:inline-flex">
            <a href="#request">Request a design</a>
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="md:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </Button>
        </div>
      </div>

      <div
        id="mobile-nav"
        className={cn(
          "md:hidden overflow-hidden border-t border-border bg-background transition-[max-height,opacity] duration-200 ease-[cubic-bezier(0.22,1,0.36,1)]",
          open ? "max-h-[100dvh] opacity-100" : "max-h-0 opacity-0",
        )}
      >
        <nav className="flex min-h-[calc(100dvh-4rem)] flex-col px-6 py-8" aria-label="Mobile">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="border-b border-border py-4 font-serif text-4xl tracking-tight text-foreground"
            >
              {item.label}
            </a>
          ))}
          <div className="mt-8 flex flex-col gap-3">
            <Button asChild size="lg">
              <a href="#request" onClick={() => setOpen(false)}>
                Request a design
              </a>
            </Button>
            <Button asChild variant="outline" size="lg">
              <a
                href={whatsappHref(defaultWhatsappText())}
                target="_blank"
                rel="noreferrer"
                onClick={() => setOpen(false)}
              >
                WhatsApp {BRAND.whatsappDisplay}
              </a>
            </Button>
          </div>
        </nav>
      </div>
    </header>
  );
}
