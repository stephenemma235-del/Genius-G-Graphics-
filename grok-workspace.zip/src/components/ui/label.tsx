import type { LabelHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Label({
  className,
  ...props
}: LabelHTMLAttributes<HTMLLabelElement>) {
  return (
    <label
      className={cn(
        "text-mark font-medium tracking-mark text-muted-foreground uppercase",
        className,
      )}
      {...props}
    />
  );
}
