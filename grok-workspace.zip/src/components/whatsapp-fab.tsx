import { MessageCircle } from "lucide-react";
import { BRAND, defaultWhatsappText, whatsappHref } from "@/lib/brand";

export function WhatsappFab() {
  return (
    <a
      href={whatsappHref(defaultWhatsappText())}
      target="_blank"
      rel="noreferrer"
      className="fixed right-4 bottom-[max(1rem,env(safe-area-inset-bottom))] z-30 inline-flex h-12 items-center gap-2 rounded-full bg-primary px-4 text-sm font-medium text-primary-foreground shadow-[var(--shadow-border-hover)] transition-transform duration-150 ease-out active:scale-[0.96] md:hidden"
      aria-label={`Chat on WhatsApp ${BRAND.whatsappDisplay}`}
    >
      <MessageCircle className="size-4" strokeWidth={1.75} />
      <span className="pr-0.5">WhatsApp</span>
    </a>
  );
}
