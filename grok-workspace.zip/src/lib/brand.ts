export const BRAND = {
  name: "Genius G Graphic Designs",
  short: "Genius G",
  tagline: "Where genius meets design",
  city: "Ado Ekiti",
  state: "Ekiti State",
  country: "Nigeria",
  whatsapp: "2349059030476",
  whatsappDisplay: "+234 905 903 0476",
} as const;

export const SERVICES = [
  {
    id: "flyers",
    title: "Flyers",
    copy: "Events, churches, campuses, and shops. Print-ready and made to be read at a glance.",
  },
  {
    id: "logos",
    title: "Logos",
    copy: "Marks that hold up on a phone screen, a stamp, and a shop sign.",
  },
  {
    id: "branding",
    title: "Branding",
    copy: "Name, colours, type, and stationery so the whole business speaks with one voice.",
  },
  {
    id: "banners",
    title: "Banners",
    copy: "Street-scale type for openings, campaigns, and indoor displays.",
  },
  {
    id: "frames",
    title: "Picture frames",
    copy: "Portraits, citations, and memorabilia — designed, printed, and framed.",
  },
  {
    id: "studio",
    title: "Full studio",
    copy: "If a graphic designer does it, we do it. Tell us the job; we will shape the brief.",
  },
] as const;

export const WORK = [
  {
    src: "/work/flyer-sunset.jpg",
    title: "Ado Sunset Fest",
    kind: "Flyer",
    alt: "Cream and black event flyer for Ado Sunset Fest on a studio table",
  },
  {
    src: "/work/logo-aura.jpg",
    title: "Aura Atelier",
    kind: "Logo",
    alt: "Logo exploration sheet for Aura Atelier pinned on a studio wall",
  },
  {
    src: "/work/branding-noir.jpg",
    title: "Noir House",
    kind: "Branding",
    alt: "Noir House letterhead, cards, and envelope laid on cream paper",
  },
  {
    src: "/work/banner-opening.jpg",
    title: "Grand Opening",
    kind: "Banner",
    alt: "Cream and black grand opening banner on a shopfront in Ado Ekiti",
  },
  {
    src: "/work/frames.jpg",
    title: "Portrait set",
    kind: "Frames",
    alt: "Three black picture frames with black-and-white portraits on a cream wall",
  },
  {
    src: "/work/flyer-thanksgiving.jpg",
    title: "Thanksgiving service",
    kind: "Flyer",
    alt: "Stack of cream church thanksgiving flyers printed in black ink",
  },
] as const;

export function whatsappHref(text?: string) {
  const base = `https://wa.me/${BRAND.whatsapp}`;
  if (!text) return base;
  return `${base}?text=${encodeURIComponent(text)}`;
}

export function defaultWhatsappText() {
  return `Hello ${BRAND.name}, I would like to request a design.`;
}
