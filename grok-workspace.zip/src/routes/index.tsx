import { createFileRoute } from "@tanstack/react-router";
import { ArrowDown, MapPin, Monitor, Printer } from "lucide-react";
import { RequestForm } from "@/components/request-form";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { WhatsappFab } from "@/components/whatsapp-fab";
import { Button } from "@/components/ui/button";
import { BRAND, SERVICES, WORK, defaultWhatsappText, whatsappHref } from "@/lib/brand";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <div id="top" className="min-h-dvh bg-background text-foreground">
      <SiteHeader />
      <main className="pb-16 md:pb-0">
        <Hero />
        <Services />
        <Work />
        <Delivery />
        <Process />
        <Request />
      </main>
      <SiteFooter />
      <WhatsappFab />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="mx-auto grid max-w-6xl px-5 pb-20 pt-12 sm:px-8 sm:pt-16 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:gap-12 lg:pb-28 lg:pt-20">
        <div>
          <p className="reveal text-mark tracking-mark text-muted-foreground uppercase">
            {BRAND.city} · {BRAND.country}
          </p>
          <h1 className="reveal reveal-delay-1 mt-5 font-serif text-display leading-[0.95] tracking-display text-foreground">
            {BRAND.tagline}.
          </h1>
          <p className="reveal reveal-delay-2 mt-6 max-w-md text-lead text-muted-foreground">
            Flyers, logos, branding, banners, and picture frames. Physical
            prints in {BRAND.city}. Virtual files anywhere in Nigeria — once
            payment is in.
          </p>
          <div className="reveal reveal-delay-3 mt-8 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg">
              <a href="#request">Request a design</a>
            </Button>
            <Button asChild variant="outline" size="lg">
              <a
                href={whatsappHref(defaultWhatsappText())}
                target="_blank"
                rel="noreferrer"
              >
                Chat on WhatsApp
              </a>
            </Button>
          </div>
        </div>
        <div className="reveal reveal-delay-2 mt-14 flex justify-center lg:mt-0">
          <div className="relative w-full max-w-md rounded-xl bg-card px-8 py-10 shadow-[var(--shadow-border)] sm:px-12 sm:py-14">
            <img
              src="/logo.png"
              alt={`${BRAND.name} logo`}
              className="mx-auto h-auto w-full max-w-xs"
            />
            <p className="mt-8 text-center text-mark tracking-mark text-muted-foreground uppercase">
              {BRAND.tagline}
            </p>
          </div>
        </div>
      </div>
      <a
        href="#services"
        className="mx-auto mb-10 flex h-11 w-11 items-center justify-center text-muted-foreground transition-colors duration-150 hover:text-foreground"
        aria-label="See services"
      >
        <ArrowDown className="size-4" />
      </a>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="scroll-mt-20 border-t border-border">
      <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-24">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-mark tracking-mark text-muted-foreground uppercase">
              The studio
            </p>
            <h2 className="mt-3 font-serif text-section tracking-tight">
              Everything a designer does.
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-muted-foreground sm:text-right">
            One brief. One WhatsApp chat. From a single flyer to a full brand.
          </p>
        </div>
        <ol className="mt-12 grid gap-px overflow-hidden rounded-xl bg-border shadow-[var(--shadow-border)] sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service, index) => (
            <li key={service.id} className="bg-card p-6 sm:p-8">
              <p className="font-serif text-sm text-muted-foreground">
                {String(index + 1).padStart(2, "0")}
              </p>
              <h3 className="mt-5 font-serif text-3xl tracking-tight">
                {service.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {service.copy}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function Work() {
  return (
    <section id="work" className="scroll-mt-20 border-t border-border bg-muted/40">
      <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-24">
        <p className="text-mark tracking-mark text-muted-foreground uppercase">
          Selected work
        </p>
        <h2 className="mt-3 font-serif text-section tracking-tight">
          Ink on paper.
        </h2>
        <ul className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {WORK.map((piece) => (
            <li key={piece.src} className="group">
              <div className="overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]">
                <img
                  src={piece.src}
                  alt={piece.alt}
                  className="work-frame aspect-work w-full object-cover transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-105"
                />
              </div>
              <div className="mt-4 flex items-baseline justify-between gap-4">
                <h3 className="font-serif text-xl tracking-tight">{piece.title}</h3>
                <p className="text-mark tracking-mark text-muted-foreground uppercase">
                  {piece.kind}
                </p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function Delivery() {
  return (
    <section id="delivery" className="scroll-mt-20 border-t border-border">
      <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-24">
        <p className="text-mark tracking-mark text-muted-foreground uppercase">
          How it arrives
        </p>
        <h2 className="mt-3 max-w-xl font-serif text-section tracking-tight">
          Printed in Ado Ekiti. Sent everywhere else.
        </h2>
        <div className="mt-12 grid gap-4 lg:grid-cols-2">
          <article className="rounded-xl bg-card p-7 shadow-[var(--shadow-border)] sm:p-10">
            <Printer className="size-5" strokeWidth={1.5} />
            <h3 className="mt-6 font-serif text-3xl tracking-tight">
              Physical delivery
            </h3>
            <p className="mt-2 flex items-center gap-2 text-sm text-muted-foreground">
              <MapPin className="size-3.5" />
              {BRAND.city} only
            </p>
            <p className="mt-5 max-w-md text-sm leading-relaxed text-muted-foreground">
              Flyers, banners, and framed pieces we can print and put in your
              hand. If you are not in {BRAND.city}, choose virtual files and
              print locally.
            </p>
          </article>
          <article className="rounded-xl bg-foreground p-7 text-primary-foreground shadow-[var(--shadow-border)] sm:p-10">
            <Monitor className="size-5" strokeWidth={1.5} />
            <h3 className="mt-6 font-serif text-3xl tracking-tight">
              Virtual delivery
            </h3>
            <p className="mt-2 text-sm text-primary-foreground/65">
              All of Nigeria · after payment
            </p>
            <p className="mt-5 max-w-md text-sm leading-relaxed text-primary-foreground/75">
              Logos, brand kits, and print-ready artwork delivered as files.
              Pay, receive, print or post from wherever you are.
            </p>
          </article>
        </div>
      </div>
    </section>
  );
}

function Process() {
  const steps = [
    {
      n: "01",
      title: "Send the brief",
      copy: "Use the form or WhatsApp. Tell us what you need, where you are, and when you need it.",
    },
    {
      n: "02",
      title: "Agree the price",
      copy: "We confirm the job and the fee on WhatsApp before any design starts.",
    },
    {
      n: "03",
      title: "Design",
      copy: "You get drafts, you mark changes, we finish the work.",
    },
    {
      n: "04",
      title: "Deliver",
      copy: `Files anywhere in Nigeria. Prints and frames only in ${BRAND.city}.`,
    },
  ];

  return (
    <section className="border-t border-border bg-muted/40">
      <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-24">
        <h2 className="font-serif text-section tracking-tight">Four steps.</h2>
        <ol className="mt-12 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step) => (
            <li key={step.n}>
              <p className="font-serif text-sm text-muted-foreground">{step.n}</p>
              <h3 className="mt-4 font-serif text-2xl tracking-tight">{step.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {step.copy}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function Request() {
  return (
    <section id="request" className="scroll-mt-20 border-t border-border">
      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 sm:py-24 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20">
        <div>
          <p className="text-mark tracking-mark text-muted-foreground uppercase">
            The brief
          </p>
          <h2 className="mt-3 font-serif text-section tracking-tight">
            Request a design.
          </h2>
          <p className="mt-5 max-w-sm text-lead text-muted-foreground">
            Fill this in and it opens WhatsApp with your message ready to send
            to {BRAND.whatsappDisplay}.
          </p>
          <a
            href={whatsappHref(defaultWhatsappText())}
            target="_blank"
            rel="noreferrer"
            className="mt-8 inline-flex min-h-11 items-center text-sm underline-offset-4 hover:underline"
          >
            Or skip the form and chat now
          </a>
        </div>
        <div className="rounded-xl bg-muted/60 p-5 sm:p-8">
          <RequestForm />
        </div>
      </div>
    </section>
  );
}
